# Skip Prime Video Intro

This is an addon for Firefox or other browsers using the WebExtensions API.
It automatically skips the intro on Amazon Prime Video when the 'Skip Intro' button is shown.
In addition, ads and flashbacks will be skipped and the next episode of a series is started directly as soon as this is displayed in the video player.

## Installation 

You can download and install the addon from the official Mozilla addon website:
[Skip Prime Video Intro on addons.mozilla.org](https://addons.mozilla.org/en-US/firefox/addon/skip-prime-video-intro/)